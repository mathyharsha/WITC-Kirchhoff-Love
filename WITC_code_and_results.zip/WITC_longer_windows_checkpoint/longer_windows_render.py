import numpy as np,pandas as pd
from PIL import Image,ImageDraw
from longer_windows_run import OUT
from gap44_show import palette,stack
from render_long import image,font
data={s:np.load(OUT/f'{s}_input.npz') for s in ['intact','damaged']};cs=pd.read_csv(OUT/'chunk_metrics.csv')
for n in [100,50]:
 panels=[('High-SNR reference',stack(*(data[s]['reference'] for s in data))),('Observed low-SNR',stack(*(np.where(data[s]['mask'][...,None],data[s]['low'],0) for s in data))),('20 µs joint fit',stack(*(np.load(OUT/f'{s}_joint20.npy') for s in data))),(f'{n/10:g} µs chunks',stack(*(np.load(OUT/f'{s}_w{n}_stitched.npy') for s in data)))]
 frames=[];pal=palette()
 for t in range(200):
  j=t//n+1;im=Image.new('RGB',(1070,490),'white');d=ImageDraw.Draw(im)
  d.text((12,8),f'{n/10:g} µs windows · 48,000 Adam steps per chunk · Start 20 µs',font=font(20,True),fill='#162830')
  d.text((12,37),f'44 × 88 missing rectangle · Independent chunk {j}/{200//n} · One atom per chunk',font=font(14),fill='#2d3f48')
  d.text((1058,37),f'{20+t/10:.1f} µs',anchor='ra',font=font(16),fill='#162830')
  for col,(title,fields) in enumerate(panels):
   x=130+col*234;d.text((x+110,66),title,anchor='ma',font=font(15,True),fill='#162830')
   for row,a in enumerate(fields):
    y=95+row*116
    if col==0:d.text((10,y+43),['Intact','Damaged','Damaged −\nintact'][row],font=font(15,True),fill='#162830')
    im.paste(Image.fromarray(image(a[:,:,t])).resize((220,110),Image.Resampling.NEAREST),(x,y));d.rectangle((x+13,y+7,x+206,y+102),outline=(245,165,42),width=1)
  c=cs[(cs.window_us==n/10)&(cs.chunk==j)].set_index('specimen').c_m2_s
  d.text((12,445),f'Chunk c: intact {c["intact"]:.4f}, damaged {c["damaged"]:.4f} m²/s · Color range [−1,1]',font=font(12),fill='#2d3f48')
  d.text((12,466),'Same data and normalization · Positive exponential λ, decay length 16 pixels · Orange: unobserved block',font=font(12),fill='#2d3f48')
  frames.append(im.quantize(palette=pal,dither=Image.Dither.NONE))
 p=OUT/f'WITC_{n//10}us_windows_48000.gif';frames[0].save(p,save_all=True,append_images=frames[1:],duration=90,loop=0,optimize=False)
 frames[80].convert('RGB').save(OUT/f'WITC_{n//10}us_windows_28us.png')
 with Image.open(p) as f:assert f.n_frames==200;f.seek(199);f.load()
 print('GIF READY',p)
