import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from longer_windows_run import OUT,evaluate
rows=[];seams=[];frames=[]
for s in ['intact','damaged']:
 with np.load(OUT/f'{s}_input.npz') as f:g=f['reference'];m=f['mask']
 preds={'20 µs joint':np.load(OUT/f'{s}_joint20.npy')}
 for n in [100,50]:
  b=np.concatenate([np.load(OUT/f'{s}_w{n}_chunk{j+1}.npy') for j in range(200//n)],axis=2)
  assert b.shape==g.shape==(50,100,200) and np.isfinite(b).all()
  np.save(OUT/f'{s}_w{n}_stitched.npy',b);preds[f'{n/10:g} µs chunks']=b
 for method,b in preds.items():
  rows.append(dict(specimen=s,method=method,**evaluate(b,g,~m)))
  for t in range(200):frames.append(dict(specimen=s,method=method,time_us=20+t/10,relative_L2=np.linalg.norm((b-g)[~m,t])/np.linalg.norm(g[~m,t])))
  for idx in [50,100,150]:
   dp=b[~m,idx]-b[~m,idx-1];dg=g[~m,idx]-g[~m,idx-1]
   seams.append(dict(specimen=s,method=method,time_us=20+idx/10,jump_ratio=np.linalg.norm(dp)/np.linalg.norm(dg),jump_relative_error=np.linalg.norm(dp-dg)/np.linalg.norm(dg)))
df=pd.DataFrame(rows);df.to_csv(OUT/'comparison_metrics.csv',index=False)
pd.DataFrame(seams).to_csv(OUT/'boundary_metrics.csv',index=False)
fr=pd.DataFrame(frames);fr.to_csv(OUT/'frame_metrics.csv',index=False)
fig,axs=plt.subplots(2,1,figsize=(11,6),sharex=True,layout='constrained')
for ax,s in zip(axs,['intact','damaged']):
 for method,d in fr[fr.specimen==s].groupby('method',sort=False):ax.plot(d.time_us,d.relative_L2,label=method)
 for t in [25,30,35]:ax.axvline(t,color='gray',ls=':',lw=.7)
 ax.set(title=s.capitalize(),ylabel='Missing-block relative L2 error');ax.legend();ax.grid(alpha=.2)
axs[-1].set_xlabel('Time (µs)');fig.savefig(OUT/'longer_windows_errors.png',dpi=150)
print(df.to_string(index=False));print(pd.DataFrame(seams).to_string(index=False))
