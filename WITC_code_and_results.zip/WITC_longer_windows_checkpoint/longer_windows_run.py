from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import numpy as np,pandas as pd
from scipy.fft import set_workers
import WITC_KL_long_epochs as kl
from chunk34_run import evaluate
OUT=Path('longer_windows');OUT.mkdir(exist_ok=True)
def prepare():
 from windows_fit import read
 for s in ['intact','damaged']:
  if (OUT/f'{s}_input.npz').exists():continue
  a=read(s,'low_snr',200,400);g=read(s,'high_snr_gt',200,400)
  m=np.ones((50,100),bool);m[3:47,6:94]=False
  scale=float(np.abs(a[m]).max())
  np.savez(OUT/f'{s}_input.npz',low=a,reference=g,mask=m,scale=scale)
  np.save(OUT/f'{s}_joint20.npy',np.load(f'previous/long_epochs/{s}_r16_e48000.npy'))
def fit(job):
 s,n,j=job;tag=f'{s}_w{n}_chunk{j+1}';i=j*n;k=i+n
 with np.load(OUT/f'{s}_input.npz') as f:
  a=f['low'][:,:,i:k];g=f['reference'][:,:,i:k];m=f['mask'];scale=float(f['scale'])
 lm,_=kl.distance_lambda(m,.01,16)
 state_path=OUT/f'{tag}_optimizer_latest.npz';resume=None;history=[]
 if state_path.exists():
  with np.load(state_path) as f:resume={key:f[key] for key in f.files}
  if (OUT/f'{tag}_history.csv').exists():history=pd.read_csv(OUT/f'{tag}_history.csv').to_dict('records')
 def save(state):
  tmp=OUT/f'{tag}_tmp.npz';np.savez(tmp,**state);tmp.replace(state_path)
 def progress(row):
  history.append(row);pd.DataFrame(history).to_csv(OUT/f'{tag}_history.csv',index=False);print(tag,row,flush=True)
 with set_workers(1):
  D,w,c=kl.wave_informed_mat_fac(np.where(m[...,None],a/scale,0),m,lambda_map=lm,adam_max_steps=48000,checkpoint_every=6000,state_callback=save,resume_state=resume,callback=progress,log_every=6000)
 b=kl.reconstruct(D,w,a.shape)*scale;np.save(OUT/f'{tag}.npy',b)
 row=dict(specimen=s,window_us=n/10,chunk=j+1,start_us=20+i/10,last_sample_us=20+(k-1)/10,steps=48000,c_m2_s=float(c[0]),**evaluate(b,g,~m))
 pd.DataFrame([row]).to_csv(OUT/f'{tag}_metrics.csv',index=False);print('DONE',row,flush=True);return row
if __name__=='__main__':
 prepare()
 jobs=[(s,n,j) for n in [100,50] for s in ['intact','damaged'] for j in range(200//n)]
 with ProcessPoolExecutor(8) as pool:rows=list(pool.map(fit,jobs))
 pd.DataFrame(rows).to_csv(OUT/'chunk_metrics.csv',index=False)
