from pathlib import Path
import zipfile
out=Path('longer_windows')
with zipfile.ZipFile(out/'WITC_longer_windows_checkpoint.zip','w',zipfile.ZIP_DEFLATED,compresslevel=1) as z:
 for p in out.iterdir():
  if p.suffix in ['.csv','.md','.npy','.gif','.png'] or p.name.endswith(('_optimizer_latest.npz','_input.npz')):z.write(p,str(p))
 for name in ['longer_windows_run.py','longer_windows_report.py','longer_windows_render.py','longer_windows_package.py','chunk34_run.py','WITC_KL_long_epochs.py','WITC_KL_reciprocal.py','WITC_KL_lib.py','gap44_fit.py','gap44_show.py','largest_fit.py','enlarged_fit.py','block_experiment.py','windows_fit.py','run.py','render_long.py']:z.write(name,name)
print(out/'WITC_longer_windows_checkpoint.zip')
