# Longer independent windows starting at 20 µs

Two configurations: four 5 µs windows (50 samples each) and two 10 µs windows (100 samples each), spanning indices 200:400, sample times 20.0–39.9 µs at dt=0.1 µs. Both intact and damaged specimens. Each independent window uses one full space-time atom, one learned c, 48,000 Adam steps, lr=1e-4, lambda0=0.01, gamma=1e-4, positive exponential amplitude penalty lambda(x,y)=0.01 exp(-distance/16 pixels). Same composed second-order Laplacians and conditional c updates as the prior experiment. c units are m²/s, with bounds 0.5 to 2 times PAPER_C. No overlap, blending, or warm starts between windows.

Fixed 50×100 grid, dx=dy=0.2 mm, central 44×88 missing rectangle [3:47,6:94], all 1128 exterior traces observed at every time. Shared normalization across the entire 20–39.9 µs interval per specimen, computed only from observed low-SNR values. High-SNR data are evaluation-only. No extra registration for damaged-minus-intact.

The saved 20 µs joint 48,000-step baseline was verified against the full data/configuration fingerprint in its optimizer state; reconstructing that state reproduces the baseline array exactly (maximum difference zero for both specimens). Thus the spatial frame, time coverage, input normalization, and penalty parameters are matched. Optimization budgets are 48,000 per independent fit, not matched total work across configurations. Effective regularization can still depend on window length through the objective's observed-data norm, as in the original implementation.

Unclipped metrics evaluate all missing points. GIFs have a common [-1,1] display color scale. Boundary diagnostics compare frame changes to the reference; the physical reference need not have zero change. At 25 and 35 µs, only 5 µs chunks have joins; 10 µs chunks have a join at 30 µs. The 20 µs joint fit has no internal joins.

Reproduce with OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 longer_windows_run.py, then longer_windows_report.py and longer_windows_render.py. Input arrays, baseline predictions, and optimizer checkpoints are included. The runner resumes saved states, and requires NumPy, SciPy, Pandas; reporting uses Matplotlib and Pillow. Inputs already in the package avoid needing the original raw scan files.

## Completed results

All twelve fits completed 48,000 epochs. The joint 20 µs baseline has lower total missing-block error for both specimens. Among independent windows, 5 µs is better for intact, while 10 µs is better for damaged. Short-window improvements are not monotonic with length.

comparison_metrics.csv

```
specimen       method  relative_L2  mean_spatial_PCC  rms_ratio
  intact  20 µs joint     0.783228          0.457144   0.516601
  intact 10 µs chunks     0.931496          0.337713   0.502362
  intact  5 µs chunks     0.848441          0.401639   0.514491
 damaged  20 µs joint     0.783604          0.423435   0.553549
 damaged 10 µs chunks     0.833145          0.390548   0.550430
 damaged  5 µs chunks     0.858563          0.359664   0.556440
```

chunk_metrics.csv

```
specimen  window_us  chunk  start_us  last_sample_us  steps   c_m2_s  relative_L2  mean_spatial_PCC  rms_ratio
  intact       10.0      1      20.0            29.9  48000 0.272853     0.954157          0.284577   0.533144
  intact       10.0      2      30.0            39.9  48000 0.247837     0.907440          0.390848   0.468368
 damaged       10.0      1      20.0            29.9  48000 0.238688     0.751464          0.407156   0.580618
 damaged       10.0      2      30.0            39.9  48000 0.245081     0.916305          0.373940   0.514389
  intact        5.0      1      20.0            24.9  48000 0.229171     1.139484          0.209024   0.806644
  intact        5.0      2      25.0            29.9  48000 0.240276     0.749123          0.643506   0.529277
  intact        5.0      3      30.0            34.9  48000 0.256904     0.898338          0.432242   0.490447
  intact        5.0      4      35.0            39.9  48000 0.197877     0.948310          0.321782   0.438735
 damaged        5.0      1      20.0            24.9  48000 0.234725     1.567202          0.095999   1.364936
 damaged        5.0      2      25.0            29.9  48000 0.240545     0.753872          0.637478   0.541874
 damaged        5.0      3      30.0            34.9  48000 0.252960     0.900545          0.434430   0.531887
 damaged        5.0      4      35.0            39.9  48000 0.211572     0.988348          0.270751   0.504543
```

boundary_metrics.csv

```
specimen       method  time_us  jump_ratio  jump_relative_error
  intact  20 µs joint     25.0    0.892167             1.037284
  intact  20 µs joint     30.0    0.612853             0.645492
  intact  20 µs joint     35.0    1.372195             1.507458
  intact 10 µs chunks     25.0    0.998521             1.236672
  intact 10 µs chunks     30.0    2.807093             3.082648
  intact 10 µs chunks     35.0    1.370678             1.503623
  intact  5 µs chunks     25.0    3.961461             4.192229
  intact  5 µs chunks     30.0    2.682451             3.051306
  intact  5 µs chunks     35.0    6.239399             5.991836
 damaged  20 µs joint     25.0    0.829701             0.848713
 damaged  20 µs joint     30.0    0.623706             0.704536
 damaged  20 µs joint     35.0    1.002608             1.284074
 damaged 10 µs chunks     25.0    0.844540             0.858822
 damaged 10 µs chunks     30.0    2.791407             3.020775
 damaged 10 µs chunks     35.0    1.032310             1.306490
 damaged  5 µs chunks     25.0    3.697261             3.799358
 damaged  5 µs chunks     30.0    2.852785             3.141551
 damaged  5 µs chunks     35.0    4.628545             4.525752
```
