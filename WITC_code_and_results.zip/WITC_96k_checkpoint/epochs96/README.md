# Extension from48000 to96000 Adam steps

Same configuration: one full space-time atom, lambda=.01 exp(-distance/16), gamma=1e-4, Adam lr=1e-4, 44x88 centered missing block, all1128 exterior observations, time20–39.9us on50x100 spatial grid. c is conditionally updated every step. Uniform physics and coefficient penalties, strictly positive spatial amplitude penalty. Original physical-space data normalization and evaluation unchanged.

Resumes both48000-step states including Adam moments without reinitialization. The optimizer verifies a fingerprint of observed data, mask, lambda map and fixed hyperparameters. Total requested step count is96000, not96000 additional steps. Intermediate evaluation/state snapshots every6000 steps. epochs96_run.py resumes automatically from epochs96/*_optimizer_latest.npz.

GIF columns: high-SNR reference,48000,72000,96000. Rows: intact,damaged,raw damaged-minus-intact. Shared color range[-1,1]; clipping is for display only. Metrics evaluate the full missing rectangle using unclipped arrays. Reference data is used only for evaluation. Additional iterations do not imply convergence or recovery of the true material coefficient.

## Completed results

specimen,radius_pixels,steps,c_m2_s,relative_L2,mean_spatial_PCC,rms_ratio
damaged,16,48000,0.2380609932883059,0.7836044312996383,0.4234354905795716,0.5535486224180437
damaged,16,54000,0.2372320349920598,0.7831089674334722,0.4227366506778798,0.5602739583795636
damaged,16,60000,0.236441134263241,0.7829199550258666,0.4219312821504741,0.566483310062037
damaged,16,66000,0.2356804865375273,0.7830013888984875,0.4210296110251157,0.5722306057622041
damaged,16,72000,0.2349455069122317,0.7833257705075101,0.4200432889479442,0.5775523014420537
damaged,16,78000,0.2342347169578535,0.7838683558161911,0.4189827413142719,0.5824663618073583
damaged,16,84000,0.2335519691832609,0.7845991725252478,0.4178667272132502,0.5869583129890893
damaged,16,90000,0.2329198685184058,0.7854566056837813,0.41675023375693,0.5909085602039049
damaged,16,96000,0.2324994849756896,0.7861240857707347,0.4159630445561079,0.5934154313803599
intact,16,48000,0.2378857930458835,0.78322811865402,0.4571444202862635,0.5166013065037146
intact,16,54000,0.2372211506896737,0.7820384480312399,0.4569078343718788,0.5224219565898135
intact,16,60000,0.2365852143540307,0.7810644558318219,0.4565827702724093,0.5278392843921199
intact,16,66000,0.2359734291547534,0.7802824649986855,0.4561795602805354,0.5328932109300232
intact,16,72000,0.2353842823755515,0.7796766251893681,0.4557061083941185,0.5376052753461887
intact,16,78000,0.2348199646911856,0.779234197673772,0.455173360410743,0.5419712171718114
intact,16,84000,0.2342929507265575,0.778944737140652,0.454605171324817,0.545913757955416
intact,16,90000,0.2338804453675807,0.7788038490658918,0.4541115025505493,0.5489042571641785
intact,16,96000,0.2338276407324143,0.7787927576054177,0.4540442844002564,0.5492775379751321

intact: relative error change from48000 to96000 = -0.5663%. Lowest evaluated error in this extension at 96000 steps: 0.778792758.
damaged: relative error change from48000 to96000 = 0.3215%. Lowest evaluated error in this extension at 60000 steps: 0.782919955.

This extension shows diminishing returns. More recovered RMS amplitude does not imply better phase or spatial structure: mean spatial correlation decreases slightly. The best-step comparison uses reference data retrospectively and is not independently validated early stopping. The original48000-step optimizer states were resumed without resetting Adam moments. After an interruption, the final12000 steps were replayed from the saved84000-step states.
