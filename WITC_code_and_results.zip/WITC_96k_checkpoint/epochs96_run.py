from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
from itertools import product
import numpy as np,pandas as pd
from scipy.fft import set_workers
from gap44_fit import masks,hole
from windows_fit import read,metrics
import WITC_KL_long_epochs as kl
out=Path('epochs96');out.mkdir(exist_ok=True)
def run(job):
 s,r=job;m=masks(s)['exterior'];a=read(s,'low_snr',200,400);g=read(s,'high_snr_gt',200,400);scale=abs(a[m]).max()
 lm=np.full(m.shape,.01) if r==0 else kl.distance_lambda(m,.01,r)[0]
 tag=f'{s}_r{r}';rows=[];history=[]
 state_path=out/f'{tag}_optimizer_latest.npz'
 resume=None
 if state_path.exists():
  with np.load(state_path,allow_pickle=False) as f:resume={k:f[k] for k in f.files}
  if (out/f'{tag}_metrics.csv').exists():rows=pd.read_csv(out/f'{tag}_metrics.csv').to_dict('records')
  if (out/f'{tag}_history.csv').exists():history=pd.read_csv(out/f'{tag}_history.csv').to_dict('records')
 def checkpoint(step,D,w,c):
  if step not in [54000,60000,66000,72000,78000,84000,90000,96000]:return
  b=kl.reconstruct(D,w,a.shape)*scale;np.save(out/f'{tag}_e{step}.npy',b)
  err,pcc=metrics(b,g,~hole)
  rows.append(dict(specimen=s,radius_pixels=r,steps=step,c_m2_s=float(c[0]),relative_L2=err,mean_spatial_PCC=pcc,rms_ratio=np.linalg.norm(b[hole])/np.linalg.norm(g[hole])))
  pd.DataFrame(rows).to_csv(out/f'{tag}_metrics.csv',index=False)
  print('CHECKPOINT',rows[-1],flush=True)
 def save_state(state):
  np.savez(out/f'{tag}_optimizer_e{int(state["step"])}.npz',**state)
  tmp=out/f'{tag}_optimizer_tmp.npz';np.savez(tmp,**state);tmp.replace(state_path)
 def progress(row):
  history.append(row);pd.DataFrame(history).to_csv(out/f'{tag}_history.csv',index=False);print(tag,row,flush=True)
 with set_workers(4):kl.wave_informed_mat_fac(np.where(m[...,None],a/scale,0),m,lambda_map=lm,adam_max_steps=96000,checkpoint_callback=checkpoint,checkpoint_every=6000,resume_state=resume,state_callback=save_state,callback=progress)
 return rows
if __name__=='__main__':
 rows=[]
 with ProcessPoolExecutor(2) as pool:
  for f in as_completed([pool.submit(run,j) for j in product(['intact','damaged'],[16])]):rows+=f.result()
 pd.DataFrame(rows).to_csv(out/'metrics.csv',index=False)
