from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
out=Path('epochs96');df=pd.concat([pd.read_csv(out/f'{s}_r16_metrics.csv') for s in ['intact','damaged']],ignore_index=True)
df=df[df.steps>=48000].sort_values(['specimen','steps']);df.to_csv(out/'WITC_48k_to_96k_metrics.csv',index=False)
fig,ax=plt.subplots(1,3,figsize=(13,4),layout='constrained')
for s in ['intact','damaged']:
 d=df[df.specimen==s]
 for a,col in zip(ax,['relative_L2','mean_spatial_PCC','rms_ratio']):a.plot(d.steps,d[col],marker='o',label=s.capitalize())
for a,title in zip(ax,['Gap relative L2 error (lower is better)','Mean spatial correlation','Gap RMS / reference RMS']):
 a.set(xlabel='Adam steps',title=title);a.grid(alpha=.2);a.legend()
fig.savefig(out/'reconstruction_progress_96k.png',dpi=170)
fig,ax=plt.subplots(1,2,figsize=(11,4),layout='constrained')
for s in ['intact','damaged']:
 h=pd.read_csv(out/f'{s}_r16_history.csv').drop_duplicates('step',keep='last').sort_values('step')
 ax[0].plot(h.step,h.objective,label=s.capitalize());ax[1].plot(h.step,h.c,label=s.capitalize())
for a,title in zip(ax,['Training objective','Estimated c (m²/s)']):
 a.set(xlabel='Adam steps',title=title);a.grid(alpha=.2);a.legend();a.axvline(48000,color='grey',ls=':',lw=1)
fig.savefig(out/'optimization_history_96k.png',dpi=170)
print(df.to_string(index=False))
