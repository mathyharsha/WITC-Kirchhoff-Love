from windows_fit import read, metrics
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
from itertools import product
import numpy as np,pandas as pd
import WITC_KL_reciprocal as kl
from largest_fit import masks as old_masks
out=Path('gap44')
hole=np.zeros((50,100),bool)
hole[3:47,6:94]=True
old36=np.zeros_like(hole);old36[7:43,14:86]=True
previous=np.zeros_like(hole);previous[11:39,22:78]=True
original=np.zeros_like(hole);original[15:35,30:70]=True
core=np.zeros_like(hole);core[20:30,40:60]=True
def masks(s):
 prev=old_masks(s)['sparse']
 sparse=prev.copy() & ~hole
 target=round(1128*1250/2408)
 rng=np.random.default_rng(42)
 if sparse.sum()>target:
  sparse.flat[rng.choice(np.flatnonzero(sparse),int(sparse.sum()-target),replace=False)]=False
 else:
  sparse.flat[rng.choice(np.flatnonzero(~hole & ~sparse),int(target-sparse.sum()),replace=False)]=True
 assert sparse.sum()==target and not (sparse & hole).any()
 return {'exterior':~hole,'sparse':sparse}
def run(pair):
 s,case=pair
 mask=masks(s)[case]
 a=read(s,'low_snr',200,500)
 scale=np.max(np.abs(a[mask]))
 obs=np.where(mask[...,None],a/scale,0)
 assert not np.any(obs[hole])
 D,w,c=kl.wave_informed_mat_fac(obs,mask,count=1,gradient_descent=True,gamma_coeff=1e-4,lambda_coeff=.025,adam_lr=1e-4,adam_max_steps=3000,tolerance=0)
 b=kl.reconstruct(D,w,a.shape)*scale
 g=read(s,'high_snr_gt',200,500)
 np.save(out/f'{s}_{case}.npy',b)
 regions={'block':hole,'previous_36x72':old36,'previous_28x56':previous,'original_block':original,'original_core':core,'all_missing':~mask}
 rows=[]
 for label,reg in regions.items():
  for window,ts in [('20.0–49.9',slice(None)),('24.5–32.9',slice(45,130))]:
   err,pcc=metrics(b[:,:,ts],g[:,:,ts],~reg)
   amp=np.linalg.norm(b[reg][:,ts])/np.linalg.norm(g[reg][:,ts])
   rows.append(dict(specimen=s,mask=case,observed_sites=int(mask.sum()),c_m2_s=c.item(),region=label,sites=int(reg.sum()),window_us=window,relative_L2=err,mean_spatial_PCC=pcc,rms_ratio=amp))
 print(s,case,rows[0],flush=True)
 return rows
if __name__=='__main__':
 with ProcessPoolExecutor(4) as pool:rows=sum(pool.map(run,product(['intact','damaged'],['exterior','sparse'])),[])
 pd.DataFrame(rows).to_csv(out/'WITC_44x88_metrics.csv',index=False)
