from pathlib import Path
import zipfile
out=Path('epochs96')
with zipfile.ZipFile(out/'WITC_96k_checkpoint.zip','w',zipfile.ZIP_DEFLATED,compresslevel=1) as z:
 for p in out.iterdir():
  if p.suffix in ['.csv','.md','.npy','.gif','.png'] or p.name.endswith('_optimizer_latest.npz'):z.write(p,str(p))
 for f in ['epochs96_run.py','epochs96_render.py','epochs96_report.py','epochs96_package.py','WITC_KL_long_epochs.py','WITC_KL_reciprocal.py','WITC_KL_lib.py','gap44_fit.py','gap44_show.py','largest_fit.py','enlarged_fit.py','block_experiment.py','windows_fit.py','run.py','render_long.py']:z.write(f,f)
 for s in ['intact','damaged']:z.write(f'rank1/{s}.npz')
print(out/'WITC_96k_checkpoint.zip')
