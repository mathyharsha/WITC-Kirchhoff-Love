from windows_fit import read, metrics
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
from itertools import product
import numpy as np,pandas as pd
import WITC_KL_reciprocal as kl
from block_experiment import masks as old_masks
out=Path('enlarged')
hole=np.zeros((50,100),bool)
hole[11:39,22:78]=True
original=np.zeros_like(hole);original[15:35,30:70]=True
core=np.zeros_like(hole);core[20:30,40:60]=True
def masks(s):
 prev=old_masks(s)['sparse']
 sparse=prev.copy() & ~hole
 candidates=np.flatnonzero(~hole & ~prev)
 sparse.flat[np.random.default_rng(42).choice(candidates,int(prev.sum()-sparse.sum()),replace=False)]=True
 assert not np.any(sparse&hole) and sparse.sum()==1250
 return {'exterior':~hole,'sparse':sparse}
def run(pair):
 s,case=pair
 mask=masks(s)[case]
 a=read(s,'low_snr',200,500)
 scale=np.max(np.abs(a[mask]))
 obs=np.where(mask[...,None],a/scale,0)
 assert not np.any(obs[hole])
 D,w,c=kl.wave_informed_mat_fac(obs,mask,count=1,gradient_descent=True,gamma_coeff=1e-4,lambda_coeff=.025,adam_lr=1e-4,adam_max_steps=3000,tolerance=0)
 b=kl.reconstruct(D,w,a.shape)*scale
 g=read(s,'high_snr_gt',200,500)
 np.save(out/f'{s}_{case}.npy',b)
 regions={'block':hole,'original_block':original,'original_core':core,'all_missing':~mask}
 rows=[]
 for label,reg in regions.items():
  for window,ts in [('20.0–49.9',slice(None)),('24.5–32.9',slice(45,130))]:
   err,pcc=metrics(b[:,:,ts],g[:,:,ts],~reg)
   amp=np.linalg.norm(b[reg][:,ts])/np.linalg.norm(g[reg][:,ts])
   rows.append(dict(specimen=s,mask=case,observed_sites=int(mask.sum()),c_m2_s=c.item(),region=label,sites=int(reg.sum()),window_us=window,relative_L2=err,mean_spatial_PCC=pcc,rms_ratio=amp))
 print(s,case,rows[0],flush=True)
 return rows
if __name__=='__main__':
 with ProcessPoolExecutor(4) as pool:rows=sum(pool.map(run,product(['intact','damaged'],['exterior','sparse'])),[])
 pd.DataFrame(rows).to_csv(out/'WITC_28x56_metrics.csv',index=False)
