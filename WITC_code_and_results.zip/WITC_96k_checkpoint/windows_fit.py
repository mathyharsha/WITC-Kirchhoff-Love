import numpy as np,pandas as pd,sys
from pathlib import Path
from run import unwind
import WITC_KL_reciprocal as kl
from concurrent.futures import ProcessPoolExecutor
from itertools import product
windows=[(200,330),(240,400),(200,400)]
specimens=['intact','damaged']
def read(s,kind,i,j):
 p=next((Path('scans/data')/s/kind).glob('*.pkl'))
 a=pd.read_pickle(p).to_numpy()
 return unwind(a[:,i:j].reshape(50,100,j-i))
def metrics(b,y,m):
 x=b[~m]; g=y[~m]
 rel=np.linalg.norm(x-g)/np.linalg.norm(g)
 x=x-x.mean(0);g=g-g.mean(0)
 return rel,np.mean((x*g).sum(0)/np.sqrt((x*x).sum(0)*(g*g).sum(0)))
def fit(job):
 s,(i,j)=job
 m=np.load('rank1/'+s+'.npz')['m']
 a=read(s,'low_snr',i,j);scale=abs(a[m]).max()
 if (i,j)==(245,330):
  old=np.load(f'reciprocal/{s}_free.npz'); pred,c=old['b'],old['c']
 else:
  D,w,c=kl.wave_informed_mat_fac(a/scale,m,count=1,gradient_descent=True,adam_lr=1e-4,
       adam_max_steps=5000,tolerance=0,lambda_coeff=.05,gamma_coeff=3e-5)
  pred=kl.reconstruct(D,w,a.shape)*scale
 y=read(s,'high_snr_gt',i,j)
 seg=slice(245-i,330-i)
 if (i,j)!=(245,330):np.save(f'windows/{s}_{i}_{j}.npy',pred)
 row=[s,i,j,j-i,float(c[0]),*metrics(pred,y,m),*metrics(pred[:,:,seg],y[:,:,seg],m)]
 print(row,flush=True)
 return row
if __name__=='__main__':
 with ProcessPoolExecutor(6) as pool:rows=list(pool.map(fit,product(specimens,windows)))
 rows.extend(fit((s,(245,330))) for s in specimens)
 pd.DataFrame(rows,columns='specimen start_index stop_exclusive frames c_m2_per_s full_relative_L2 full_mean_PCC original_relative_L2 original_mean_PCC'.split()).sort_values(['frames','specimen']).to_csv('windows/WITC_window_results.csv',index=False)
