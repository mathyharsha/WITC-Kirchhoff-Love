from pathlib import Path
import sys
import numpy as np
import pandas as pd
from WITC_KL_lib import wave_informed_mat_fac, reconstruct
def unwind(a):
    a=a.copy()
    a[1::2]=a[1::2,::-1].copy()
    return a
def field(p):
    x=pd.read_pickle(p).to_numpy()
    assert x.shape==(5000,1000)
    return unwind(x[:,245:330].reshape(50,100,85))
def run(s):
    root=Path('scans/data')/s
    a=field(next(root.glob('low_snr/*.pkl')))
    order=np.arange(5000)
    np.random.default_rng(42).shuffle(order)
    m=np.zeros(5000,bool);m[order[:1250]]=True
    m=unwind(m.reshape(50,100))
    scale=np.max(abs(a[m]))
    D,w,k=wave_informed_mat_fac(a/scale,m,count=5,lambda_coeff=.01,sa_maxiter=30,seed=42)
    b=reconstruct(D,w,a.shape)*scale
    gt=field(next(root.glob('high_snr_gt/*.pkl')))
    np.savez('results/'+s+'.npz',a=a,b=b,gt=gt,m=m,k=k)
    r=b[~m];g=gt[~m]
    pcc=[np.corrcoef(r[:,i],g[:,i])[0,1] for i in range(85)]
    print(s,k, np.mean(pcc), np.linalg.norm(r-g)/np.linalg.norm(g),flush=True)
if __name__=='__main__':
    run(sys.argv[1])
