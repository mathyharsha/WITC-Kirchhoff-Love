"""Kirchhoff–Love WITC for real wavefields in (ny, nx, nt) order.

The spectral dictionary and coefficients have the same layout as WITC_lib.
Use reconstruct(Dc, x, data.shape) in place of the notebook's old inverse
basis. NumPy/SciPy run on CPU. PyTorch inputs stay on the requested device.

Example (Wang et al., Ultrasonics 168, 108194, Sections 2.2–2.6):
    # low_snr is detrended, normalized, and ordered (50,100,1000).
    # Randomly observe whole spatial traces, as in the paper.
    rng = np.random.default_rng(7)
    mask = np.zeros(low_snr.shape[:2], dtype=bool)
    mask.flat[rng.choice(mask.size, mask.size // 4, replace=False)] = True
    Dc, x, cs = wave_informed_mat_fac(low_snr, mask, count=3,
                                      c_bounds=(0.2, 0.5), seed=7)
    predicted = reconstruct(Dc, x, low_snr.shape)
    # Compare predicted to the separate 300-average reference, frame by frame.
    # For defect indication evaluate kl_residual(predicted, PAPER_C) with a
    # common reference c for both specimens. Exclude spatial edges, e.g.
    # residual[3:-3, 3:-3, 1:-1], before aggregating over time.

The symmetric second differences have endpoint diagonal -1 (even extension).
This is a spectral boundary assumption on the acquisition window. The paper
instead enforces an interior-only PDE penalty. Its PINN uses fixed material
properties and a relative Huber penalty. Here the regularizer is quadratic.
"""
import math
import heapq
import warnings

import numpy as np
from scipy.fft import dctn, idctn
from scipy.optimize import minimize_scalar


def material_c(E, nu, rho, h):
    """E [Pa], nu [-], rho [kg/m^3], h [m] -> positive c [m^2/s]."""
    if not all(np.isfinite([E, nu, rho, h])) or min(E, rho, h) <= 0 or not -1 < nu < 0.5:
        raise ValueError("Invalid isotropic plate properties")
    return h * math.sqrt(E / (12 * rho * (1 - nu**2)))


PAPER_C = material_c(70e9, 0.33, 2700, 0.2e-3)


def _torch_for(a, device=None, dtype=None):
    if (type(a).__module__.split('.')[0] == 'torch' or device is not None
            or type(dtype).__module__ == 'torch'):
        import torch
        return torch
    return None


class _Grid:
    """Common cosine eigenbasis of the three lifted 1-D Laplacians."""

    def __init__(self, shape, like):
        self.shape = tuple(shape)
        self.torch = _torch_for(like)
        self.like = like
        if len(shape) != 3 or min(shape) < 2:
            raise ValueError("Expected three axes (ny,nx,nt), each of length >= 2")
        if self.torch:
            self.bases = []
            for n in shape:
                i = np.arange(n)
                V = np.sqrt(2 / n) * np.cos(np.pi * (i[:, None] + 0.5) * i / n)
                V[:, 0] = 1 / np.sqrt(n)
                self.bases.append(self.array(V))

    def array(self, a):
        if self.torch:
            return self.torch.as_tensor(a, dtype=self.like.dtype, device=self.like.device)
        return np.asarray(a, dtype=self.like.dtype)

    def transform(self, a, inverse=False):
        a = a.reshape(self.shape)
        if self.torch:
            for axis, V in enumerate(self.bases):
                a = (a.movedim(axis, -1) @ (V.T if inverse else V)).movedim(-1, axis)
        else:
            a = (idctn if inverse else dctn)(a, type=2, norm="ortho")
        return a if inverse else a.reshape(-1)

    def symbols(self, dx, dy, dt, length):
        if not all(np.isfinite([dx, dy, dt, length])) or min(dx, dy, dt, length) <= 0:
            raise ValueError("Spacings and reference_length must be positive and finite")
        ly, lx, lt = [-(2 * np.sin(np.pi * np.arange(n) / (2*n)) / step)**2
                      for n, step in zip(self.shape, (dy, dx, dt))]
        # (Lx + Ly)^2 = Lx^2 + 2 Lx Ly + Ly^2. Lt is already a second derivative.
        space = (ly[:, None] + lx[None, :])**2
        return self.array(length**4 * space[:, :, None]), self.array(length**4 * lt)


def reconstruct(Dc, x, shape):
    """Synthesize the unmasked field from the returned spectral factors."""
    return _Grid(shape, Dc).transform(Dc @ x, inverse=True)


def kl_residual(field, c, *, dx=2e-4, dy=2e-4, dt=1e-7):
    """Physical residual Δ²u + c⁻²u_tt, with the same boundary closure as fitting."""
    if not math.isfinite(c) or c <= 0:
        raise ValueError("c must be positive and finite")
    grid = _Grid(field.shape, field)
    if not (field.is_floating_point() if grid.torch else np.issubdtype(field.dtype, np.floating)):
        raise ValueError("field must be floating point")
    space, time = grid.symbols(dx, dy, dt, 1.0)
    return grid.transform((space + time / c**2) * grid.transform(field).reshape(field.shape), True)


def _polar_c(score, space, time, zz, gamma, lo, hi, budget, rtol):
    """Search directly over c, pruning intervals by termwise upper bounds on score.
    The bound is on the polar *score*, not on the distance to the true c.
    """
    def upper(a, b):
        # time <= 0, so the residual symbol increases with c.
        lower_symbol = (space + time/a**2).reshape(-1)
        upper_symbol = (space + time/b**2).reshape(-1)
        # Distance of zero from the interval of residual symbols.
        nearest = lower_symbol.clip(0, None) + (-upper_symbol).clip(0, None)
        return float((zz / (1 + gamma * nearest**2)).sum())

    grid = np.linspace(lo, hi, 33)
    values = [score(c) for c in grid]
    i = int(np.argmax(values))
    cbest, best = grid[i], values[i]
    if best == 0:
        return lo
    for i in range(1, len(grid)-1):
        if values[i] > values[i-1] and values[i] >= values[i+1]:
            opt = minimize_scalar(lambda c: -score(c), method="bounded",
                                  bounds=(grid[i-1], grid[i+1]))
            if -opt.fun > best:
                cbest, best = opt.x, -opt.fun
    queue = [(-upper(a,b), a,b) for a,b in zip(grid[:-1], grid[1:])]
    heapq.heapify(queue)
    for _ in range(budget):
        if not queue or -queue[0][0] <= best*(1+rtol):
            break
        _, a, b = heapq.heappop(queue)
        mid = (a+b)*0.5
        value = score(mid)
        if value > best:
            cbest, best = mid, value
        for x,y in ((a,mid),(mid,b)):
            bound = upper(x,y)
            if bound > best*(1+rtol):
                heapq.heappush(queue, (-bound,x,y))
    if queue and -queue[0][0] > best*(1+rtol):
        warnings.warn(f"Polar search budget reached; relative score gap bound "
                      f"{-queue[0][0]/best-1:.3g}", RuntimeWarning, stacklevel=2)
    return cbest


def wave_informed_mat_fac(data, Trans, *, dx=2e-4, dy=2e-4, dt=1e-7,
                          c_bounds=(0.5*PAPER_C, 2*PAPER_C), reference_length=1e-3,
                          count=5, gradient_descent=False, tolerance=0.1,
                          threshold=0.1, sa_maxiter=200, polar_rtol=0.001, adam_lr=1e-3,
                          adam_max_steps=500, gamma_coeff=0.3, lambda_coeff=0.1,
                          dtype=None, device=None, seed=None):
    """Return (Dc, x, c_values), one bounded c per accepted WITC atom.

    dx,dy [m], dt [s] are the actual sample spacings after any decimation.
    c_bounds are physical search bounds [m²/s]. Set both ends equal to fix c.
    The default half-to-double nominal range is an adjustable search prior.
    The objective is 0.5 ||M(Dc x in physical coordinates - data)||² plus
    (lambda/2) sum_j (||d_j||² + gamma ||R(c_j)d_j||² + x_j²),
    where R = reference_length^4 (Δ² + c⁻² Lt), gamma = gamma_coeff, and
    lambda = lambda_coeff * ||observed data||. Changing reference_length
    changes the strength of the penalty. Its default is 1 mm.
    Trans is binary, (ny,nx) or broadcastable to (ny,nx,nt). Masked values
    may be NaN. PyTorch defaults to float64, as in the original library.
    Adam updates the factors. After every step the objective is minimized exactly over c
    conditional on its atom, with projection to the specified bounds.
    sa_maxiter now bounds interval subdivisions after the deterministic initial
    scan. polar_rtol bounds relative score suboptimality if certified. A warning
    reports the remaining bound when the budget is exhausted. seed is accepted
    for notebook compatibility and has no effect.
    """
    torch = _torch_for(data, device, dtype)
    if torch:
        dtype = torch.float64 if dtype is None else dtype
        if dtype not in (torch.float32, torch.float64):
            raise ValueError("Use torch.float32 or torch.float64")
        data = torch.as_tensor(data, device=device, dtype=dtype).detach()
        mask = torch.as_tensor(Trans, device=data.device)
        xp = torch
    else:
        data = np.asarray(data, dtype=np.float64 if dtype is None else dtype)
        if data.dtype not in (np.float32, np.float64):
            raise ValueError("Use float32 or float64")
        mask = np.asarray(Trans)
        xp = np
    grid = _Grid(data.shape, data)
    space, time = grid.symbols(dx, dy, dt, reference_length)
    lo, hi = map(float, c_bounds)
    if not (0 < lo <= hi and np.isfinite(hi)):
        raise ValueError("Require 0 < c_min <= c_max < infinity")
    if not all(np.isfinite([gamma_coeff, lambda_coeff, threshold, tolerance, adam_lr])) or (
            min(gamma_coeff, threshold, tolerance) < 0 or min(lambda_coeff, adam_lr) <= 0
            or count < 0 or min(sa_maxiter, adam_max_steps) < 1):
        raise ValueError("Invalid regularization or optimization settings")
    if mask.ndim == 2:
        mask = mask[..., None]
    mask = xp.broadcast_to(mask, data.shape)
    if not bool(((mask == 0) | (mask == 1)).all()):
        raise ValueError("Expected a binary observation mask")
    mask = mask != 0
    observed = xp.where(mask, data, grid.array(0.0))
    if not bool(xp.isfinite(observed).all()):
        raise ValueError("Observed samples must be finite")

    def norm(a):
        return float(xp.linalg.norm(a.reshape(-1)))

    def stack(items):
        return torch.stack(items, dim=1) if torch else np.stack(items, axis=1)

    def symbol(c):
        return (space + time / c**2).reshape(-1)

    def residual(D, weights):
        return grid.transform(observed - mask * grid.transform(D @ weights, True))

    lam = lambda_coeff * norm(observed)
    n = math.prod(data.shape)
    D = grid.array([]).reshape(n, 0)
    weights = grid.array([])
    cs = grid.array([])
    if not np.isfinite(polar_rtol) or polar_rtol <= 0:
        raise ValueError("polar_rtol must be positive and finite")
    for _ in range(count):
        if lam == 0:
            break
        z = residual(D, weights)
        zz = z*z

        def score(c):
            r = symbol(c)
            return float((zz / (1 + gamma_coeff * r*r)).sum())

        c = lo
        if hi > lo and gamma_coeff:
            c = _polar_c(score, space, time, zz, gamma_coeff, lo, hi,
                         sa_maxiter, polar_rtol)
        polar_norm = math.sqrt(score(c))
        if polar_norm <= lam * (1 + threshold):
            break
        r = symbol(c)
        atom = z / ((1 + gamma_coeff*r*r) * polar_norm)
        # Exact line minimization along the balanced atom for masked fidelity.
        measured_norm = norm(mask * grid.transform(atom, True))
        tau = math.sqrt(polar_norm - lam) / measured_norm
        D = stack([*D.T, tau*atom])
        weights = xp.concatenate((weights, grid.array([tau])))
        cs = xp.concatenate((cs, grid.array([c])))
        if gradient_descent:
            _refine(D, weights, cs, residual, symbol, space, time, grid, xp,
                    lam, gamma_coeff, lo, hi, adam_lr, adam_max_steps, tolerance)

    return D, weights, cs


def _refine(D, weights, cs, residual, symbol, space, time, grid, xp,
            lam, gamma, lo, hi, lr, max_steps, tolerance):
    """Alternate Adam steps on the factors with exact bounded updates of c."""
    params = (D, weights)
    time2 = time*time
    cross = -space*time
    moments = [xp.zeros_like(p) for p in params]
    variances = [xp.zeros_like(p) for p in params]
    for step in range(1, max_steps + 1):
        z = residual(D, weights)
        gw = lam*weights - D.T @ z
        gd = -z[:, None] * weights
        for j, c in enumerate(cs):
            r = symbol(c)
            atom = D[:, j]
            gd[:, j] += lam * (1 + gamma*r*r) * atom
        change = 0.
        for p, g, m, v in zip(params, (gd, gw), moments, variances):
            m *= 0.9
            m += 0.1*g
            v *= 0.999
            v += 0.001*g*g
            delta = lr * (m / (1-0.9**step)) / ((v / (1-0.999**step))**0.5 + 1e-8)
            change += float(xp.linalg.norm(delta)) / (float(xp.linalg.norm(p)) + 1e-12)
            p -= delta
        if gamma and hi > lo:
            old_cs = cs.clone() if grid.torch else cs.copy()
            for j in range(len(cs)):
                energy = D[:,j].reshape(grid.shape)**2
                denominator = (energy*time2).sum()
                if float(denominator) > 0:
                    q = (energy*cross).sum() / denominator
                    cs[j] = xp.clip(q, 1/hi**2, 1/lo**2)**(-0.5)
            change += float(xp.linalg.norm(cs-old_cs)) / float(xp.linalg.norm(old_cs))
        if change < 2 * len(cs) * tolerance:
            break
