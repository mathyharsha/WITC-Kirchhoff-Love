from windows_fit import read
windows=[(200,450),(200,500)]
from PIL import Image,ImageDraw,ImageFont
from pathlib import Path
import numpy as np
from matplotlib import colormaps
root=Path('windows')
fontdir='/usr/share/fonts/truetype/dejavu/'
def font(n,bold=False):return ImageFont.truetype(fontdir+'DejaVuSans'+('-Bold' if bold else '')+'.ttf',n)
lut=(255*colormaps['RdBu_r'](np.linspace(0,1,201))[:,:3]).astype('uint8')
def image(v):return lut[np.rint((np.clip(v,-1,1)+1)*100).astype(int)]
def make(s):
 m=np.load('rank1/'+s+'.npz')['m']
 panels=[('Sparse input · 25% observed',200,500,read(s,'low_snr',200,500)),('High-SNR reference',200,500,read(s,'high_snr_gt',200,500))]
 for i,j in windows:panels.append((f'WITC · {i/10:.1f}–{(j-1)/10:.1f} µs',i,j,np.load(root/f'{s}_{i}_{j}.npy')))
 pal=Image.new('P',(1,1))
 palette=np.vstack([lut,[[180,180,180],[22,40,48],[45,63,72],[239,241,243]],np.tile(np.linspace(0,255,51,dtype='uint8')[:,None],(1,3))])
 pal.putpalette(palette.astype('uint8').ravel().tolist())
 frames=[]
 for t in range(200,500):
  im=Image.new('RGB',(610,419),'white');d=ImageDraw.Draw(im)
  d.text((14,8),s.capitalize()+' plate',font=font(22,True),fill='#162830')
  d.text((595,9),f'{t/10:.1f} µs',anchor='ra',font=font(19),fill='#162830')
  for z,(title,i,j,a) in enumerate(panels):
   x=14+(z%2)*297;y=44+(z//2)*168
   d.text((x,y),title,font=font(14,True),fill='#2d3f48')
   if i<=t<j:
    rgb=image(a[:,:,t-i])
    if z==0:rgb[~m]=180
    im.paste(Image.fromarray(rgb).resize((278,139),Image.Resampling.NEAREST),(x,y+21))
   else:
    d.rectangle((x,y+21,x+277,y+159),fill='#eff1f3')
    d.text((x+139,y+91),'Outside fit window',anchor='mm',font=font(14),fill='#2d3f48')
  d.text((14,388),'50 × 100 sites  ·  0.2 mm pitch',font=font(14),fill='#2d3f48')
  im.paste(Image.fromarray(lut[None,:,:]).resize((130,9)),(410,393))
  d.text((403,387),'Amplitude   −1',anchor='ra',font=font(14),fill='#2d3f48')
  d.text((546,387),'+1',font=font(14),fill='#2d3f48')
  frames.append(im.quantize(palette=pal,dither=Image.Dither.NONE))
 out=Path('longer')/f'WITC_20_to_50us_{s}.gif'
 frames[0].save(out,save_all=True,append_images=frames[1:],duration=90,loop=0,optimize=False)
 with Image.open(out) as gif:
  assert gif.n_frames==300
  for t in (0,100,199,249,299):gif.seek(t);gif.load()
if __name__=='__main__':
 for s in ['intact','damaged']:make(s)
