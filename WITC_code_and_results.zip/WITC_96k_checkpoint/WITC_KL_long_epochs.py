"""NumPy one-atom KL-WITC with a physical-space amplitude penalty lambda_map.

Let d=Q Dc, w be its scalar coefficient, S=||M data||. Minimize
 .5||M(w*d-data)||² + S/2 [sum(lambda_map*d²)
       + lambda_coeff*gamma_coeff*||R(c)Dc||² + lambda_coeff*w²].
Only amplitude shrinkage varies; PDE and coefficient penalties stay uniform.
R(c)=ell^4*((Lx+Ly)^2+c^-2*Lt) uses composed second-difference Laplacians.
A constant map recovers the original one-atom objective. Initialization uses
its constant-map polar search, followed by Adam on the new objective and
exact conditional c updates. No exact weighted polar/global optimum is claimed.
"""
import hashlib
import numpy as np
from scipy.ndimage import distance_transform_edt
import WITC_KL_reciprocal as base
from WITC_KL_reciprocal import reconstruct,PAPER_C,kl_residual,material_c

def distance_lambda(mask,lambda0=.01,radius=8.,*,sampling=None,floor_ratio=0.):
    """Return (coefficient map, distance). Exponential decay stays positive at every distance.

    radius is the e-folding length, not a cutoff. floor_ratio optionally
    sets a positive asymptote. A float64 tiny guard prevents underflow to zero.

    2-D default units are pixels. For 3-D masks supply sampling explicitly,
    e.g.(1/8,1/8,1/20), radius=1 for 8-pixel/20-frame spatial/temporal scales.
    c has units m²/s and is not a speed for converting time to distance.
    """
    m=np.asarray(mask)
    if m.ndim not in (2,3) or min(m.shape)<1 or not np.isin(m,[0,1]).all() or not m.any():raise ValueError('Require a binary 2-D/3-D mask with observations')
    if not np.isfinite([lambda0,radius,floor_ratio]).all() or lambda0<=0 or radius<=0 or not 0<=floor_ratio<=1:raise ValueError('Invalid taper parameters')
    if sampling is None:
        if m.ndim==3:raise ValueError('Specify sampling to define the space-time metric')
        sampling=(1.,1.)
    sampling=np.asarray(sampling,float)
    if sampling.shape!=(m.ndim,) or not np.isfinite(sampling).all() or (sampling<=0).any():raise ValueError('Invalid sampling')
    dist=distance_transform_edt(~m.astype(bool),sampling=sampling)
    with np.errstate(over="ignore", under="ignore"):
        taper=np.exp(-dist/radius)
        coefficients=lambda0*(floor_ratio+(1-floor_ratio)*taper)
    coefficients=np.maximum(coefficients,np.nextafter(0.,1.))
    return coefficients,dist

def _value_grad(atom,w,obs,mask,lm,scale,lam,gamma,r,grid):
    d=grid.transform(atom,True);res=mask*(w*d-obs);z=grid.transform(res)
    value=.5*np.sum(res**2)+.5*scale*(np.sum(lm*d*d)+lam*gamma*np.dot(r*atom,r*atom)+lam*w*w)
    gd=w*z+scale*grid.transform(lm*d)+scale*lam*gamma*r*r*atom
    return float(value),gd,float(np.dot(atom,z)+scale*lam*w)

def wave_informed_mat_fac(data,Trans,*,lambda_map=None,lambda_coeff=.01,gamma_coeff=1e-4,
        dx=2e-4,dy=2e-4,dt=1e-7,reference_length=1e-3,c_bounds=(.5*PAPER_C,2*PAPER_C),
        count=1,gradient_descent=True,adam_lr=1e-4,adam_max_steps=3000,tolerance=0.,
        sa_maxiter=200,polar_rtol=.001,callback=None,log_every=1000,
        checkpoint_callback=None,checkpoint_every=3000,
        resume_state=None,state_callback=None):
    """Return spectral Dc,w,c. Map may be 2-D, 3-D, or a C-order flat vector.

    NumPy/CPU only. Same 2-D mask at all times implies a time-constant map.
    Scalar lambda_coeff still sets uniform PDE and coefficient penalties.
    checkpoint_callback(step, Dc, w, c) receives copies for saving iterates.
    """
    if count!=1 or not gradient_descent:raise ValueError('Require one atom and active gradient descent')
    if not np.isfinite([lambda_coeff,gamma_coeff,adam_lr,tolerance]).all() or lambda_coeff<=0 or gamma_coeff<0 or adam_lr<=0 or tolerance<0 or adam_max_steps<1 or log_every<1:raise ValueError('Invalid optimization settings')
    if checkpoint_every<1:raise ValueError('checkpoint_every must be positive')
    data=np.asarray(data,dtype=float);grid=base._Grid(data.shape,data);mask=np.asarray(Trans)
    if mask.ndim==2:mask=mask[...,None]
    mask=np.broadcast_to(mask,data.shape)
    if not np.isin(mask,[0,1]).all():raise ValueError('Mask must be binary')
    mask=mask.astype(bool);obs=np.where(mask,data,0.)
    if not np.isfinite(obs).all():raise ValueError('Observed data must be finite')
    scale=float(np.linalg.norm(obs));lo,hi=map(float,c_bounds)
    if not 0<lo<=hi or not np.isfinite(hi):raise ValueError('Invalid c bounds')
    lm=np.asarray(lambda_coeff if lambda_map is None else lambda_map,dtype=float)
    if lm.ndim==1 and lm.size==data.size:lm=lm.reshape(data.shape)
    if lm.ndim==2:lm=lm[...,None]
    lm=np.broadcast_to(lm,data.shape)
    if not np.isfinite(lm).all() or (lm<=0).any():raise ValueError('Map must be finite and strictly positive')
    if scale==0:return np.zeros((data.size,1)),np.zeros(1),np.array([(lo+hi)/2])
    fingerprint=hashlib.sha256()
    for x in (obs,mask,lm,np.array([dx,dy,dt,reference_length,lo,hi,lambda_coeff,gamma_coeff,adam_lr])):
        fingerprint.update(np.ascontiguousarray(x).tobytes())
    signature=fingerprint.hexdigest()
    space,time=grid.symbols(dx,dy,dt,reference_length)
    if resume_state is None:
        Dc,w,cs=base.wave_informed_mat_fac(obs,mask,dx=dx,dy=dy,dt=dt,reference_length=reference_length,
            c_bounds=c_bounds,count=1,gradient_descent=False,lambda_coeff=lambda_coeff,gamma_coeff=gamma_coeff,sa_maxiter=sa_maxiter,polar_rtol=polar_rtol)
        if len(w)!=1:raise ValueError('Scalar initializer rejected atom; reduce lambda_coeff')
        atom=Dc[:,0].copy();weight=float(w[0]);c=float(cs[0])
        md=np.zeros_like(atom);vd=np.zeros_like(atom);mw=vw=0.;start_step=0
    else:
        if str(resume_state['signature'])!=signature:raise ValueError('Checkpoint data/configuration mismatch')
        atom=np.array(resume_state['atom'],copy=True);md=np.array(resume_state['md'],copy=True);vd=np.array(resume_state['vd'],copy=True)
        weight=float(resume_state['weight']);c=float(resume_state['c']);mw=float(resume_state['mw']);vw=float(resume_state['vw']);start_step=int(resume_state['step'])
        if start_step>adam_max_steps:raise ValueError('Checkpoint exceeds requested final step')
    for step in range(start_step+1,adam_max_steps+1):
        r=(space+time/c**2).reshape(-1)
        _,gd,gw=_value_grad(atom,weight,obs,mask,lm,scale,lambda_coeff,gamma_coeff,r,grid)
        md=.9*md+.1*gd;vd=.999*vd+.001*gd*gd;mw=.9*mw+.1*gw;vw=.999*vw+.001*gw*gw
        da=adam_lr*(md/(1-.9**step))/(np.sqrt(vd/(1-.999**step))+1e-8)
        dw=adam_lr*(mw/(1-.9**step))/(np.sqrt(vw/(1-.999**step))+1e-8)
        change=np.linalg.norm(da)/(np.linalg.norm(atom)+1e-12)+abs(dw)/(abs(weight)+1e-12)
        atom-=da;weight-=dw;old=c
        if gamma_coeff and hi>lo:
            en=atom.reshape(data.shape)**2;den=float(np.sum(en*time*time))
            if den>0:c=float(np.clip(np.sum(en*(-space*time))/den,1/hi**2,1/lo**2)**-.5)
        change+=abs(c-old)/old;stop=change<2*tolerance
        if callback and (step%log_every==0 or step==adam_max_steps or stop):
            value,_,_=_value_grad(atom,weight,obs,mask,lm,scale,lambda_coeff,gamma_coeff,(space+time/c**2).reshape(-1),grid)
            callback(dict(step=step,objective=value,c=c,relative_change=float(change)))
        if checkpoint_callback and (step%checkpoint_every==0 or step==adam_max_steps or stop):
            checkpoint_callback(step,atom[:,None].copy(),np.array([weight]),np.array([c]))
        if state_callback and (step%checkpoint_every==0 or step==adam_max_steps or stop):
            state_callback(dict(atom=atom.copy(),weight=weight,c=c,md=md.copy(),vd=vd.copy(),mw=mw,vw=vw,step=step,signature=signature))
        if stop:break
    return atom[:,None],np.array([weight]),np.array([c])
