from gap44_fit import *
from PIL import Image,ImageDraw
from render_long import font,image,lut
def stack(x,y):
 return (x,y,y-x)
def palette():
 pal=Image.new('P',(1,1))
 colors=np.vstack([lut,[[180]*3,[22,40,48],[45,63,72],[245,165,42]],np.tile(np.linspace(0,255,51,dtype='uint8')[:,None],(1,3))])
 pal.putpalette(colors.astype('uint8').ravel().tolist());return pal
def show(case):
 m=masks('intact')[case];assert np.array_equal(m,masks('damaged')[case])
 low=stack(*(read(s,'low_snr',200,500) for s in ('intact','damaged')))
 ref=stack(*(read(s,'high_snr_gt',200,500) for s in ('intact','damaged')))
 pred=stack(*(np.load(out/f'{s}_{case}.npy') for s in ('intact','damaged')))
 rows=[]
 for label,reg in [('block',hole),('previous_36x72',old36),('previous_28x56',previous),('original_block',original),('original_core',core),('all_missing',~m)]:
  for window,ts in [('20.0–49.9',slice(None)),('24.5–32.9',slice(45,130))]:
   b,g=pred[2][:,:,ts],ref[2][:,:,ts];err,corr=metrics(b,g,~reg)
   rows.append(dict(specimen='damaged_minus_intact',mask=case,observed_sites=m.sum(),region=label,sites=reg.sum(),window_us=window,relative_L2=err,mean_spatial_PCC=corr,rms_ratio=np.linalg.norm(b[reg])/np.linalg.norm(g[reg])))
 pal=palette();frames=[]
 for i in range(300):
  im=Image.new('RGB',(844,618),'white'); d=ImageDraw.Draw(im)
  d.text((12,5),f'44 × 88 gap   ·   {m.sum():,} exterior traces observed',font=font(19,True),fill='#162830');d.text((832,6),f'{(200+i)/10:.1f} µs',font=font(17),anchor='ra',fill='#162830')
  for j,title in enumerate(['Intact','Damaged','Damaged − intact']):
   x=156+j*226;d.text((x+110,36),title,anchor='ma',font=font(15,True),fill='#162830')
  for row,(name,fields) in enumerate([('Input',low),('WITC',pred),('High-SNR ref.',ref),('Gap · WITC',pred),('Gap · reference',ref)]):
   y=60+106*row;d.text((10,y+49),name,font=font(14,True),fill='#2d3f48')
   for j,f in enumerate(fields):
    x=156+j*226
    rgb=image(f[:,:,i] if row<3 else f[3:47,6:94,i])
    if row==0:rgb[~m]=180
    im.paste(Image.fromarray(rgb).resize((204,102),Image.Resampling.NEAREST),(x,y))
    if row<3:d.rectangle((x+12,y+6,x+191,y+95),outline=(245,165,42),width=1)
  d.text((12,594),'Gray = missing   ·   Bottom two rows enlarge the gap',font=font(12),fill='#2d3f48')
  im.paste(Image.fromarray(lut[None,:,:]).resize((96,9)),(684,598))
  d.text((680,591),'Amplitude   −1',font=font(12),anchor='ra',fill='#2d3f48');d.text((784,591),'+1',font=font(12),fill='#2d3f48')
  frames.append(im.quantize(palette=pal,dither=Image.Dither.NONE))
 path=out/f'WITC_44x88_{case}_difference.gif'
 frames[0].save(path,save_all=True,append_images=frames[1:],duration=90,loop=0,optimize=False)
 with Image.open(path) as im:assert im.n_frames==300;im.seek(299);im.load()
 return rows
if __name__=='__main__':
 file=out/'WITC_44x88_metrics.csv'
 df=pd.read_csv(file);df=df[df.specimen!='damaged_minus_intact']
 df=pd.concat([df,pd.DataFrame(show('exterior')+show('sparse'))],ignore_index=True);df.to_csv(file,index=False)
