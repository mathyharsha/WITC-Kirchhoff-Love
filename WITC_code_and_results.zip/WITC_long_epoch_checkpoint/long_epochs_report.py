from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
out=Path('long_epochs')
df=pd.read_csv(out/'metrics.csv')
fig,axes=plt.subplots(2,3,figsize=(12,7),layout='constrained')
for i,s in enumerate(['intact','damaged']):
 for r,label in [(16,'Exponential r=16')]:
  d=df[(df.specimen==s)&(df.radius_pixels==r)].sort_values('steps')
  for j,col in enumerate(['relative_L2','rms_ratio','c_m2_s']):axes[i,j].plot(d.steps,d[col],marker='o',label=label)
 for j,title in enumerate(['Gap relative L2 error ↓','Gap RMS / reference RMS','Estimated c (m²/s)']):
  axes[i,j].set(title=f'{s.capitalize()}: {title}',xlabel='Adam steps');axes[i,j].grid(alpha=.2)
axes[0,0].legend();fig.savefig(out/'epoch_comparison.png',dpi=160)
print(df.to_string(index=False))
