# Fixed configuration: longer Adam optimization

One full space-time atom; c reestimated each step; lambda=.01 exp(-distance/16), distance in spatial pixels; gamma=1e-4; Adam learning rate=1e-4; time20–39.9us; central44x88 unobserved rectangle on50x100 grid; all1128 exterior traces observed. No change in hyperparameters across checkpoints. Physics penalty remains uniform; lambda is strictly positive. Spatial mask is constant in time. Data/reference normalization matches previous runs.

Reconstruction comparisons at12000,24000,48000 steps; full optimizer state saved every6000 steps. The initial12000 steps are reproduced because the earlier experiment saved predictions but not Adam moments. New states preserve moments, coefficient, atom, c, step, and a data/configuration fingerprint. long_epochs_run.py automatically resumes from the latest optimizer state in long_epochs/. The requested48000 steps is a total, not48000 additional steps. Saved state is intended for the same data, mask and optimization hyperparameters; mismatch is rejected. Original data under scans/data must be available to reproduce or resume.

GIF rows show intact, damaged, and raw damaged-minus-intact; columns reference and12000/24000/48000-step fields. Color scale[-1,1] is identical; metrics are computed on unclipped predictions inside the missing rectangle. Difference fields are not additionally registered/calibrated. High-SNR reference data is used for evaluation only. This is a controlled optimization-duration experiment, not independent validation or evidence of global convergence.

## Results

| Specimen | Steps | Gap relative L2 error | Mean spatial PCC | Gap RMS/reference RMS | c (m²/s) |
|---|---:|---:|---:|---:|---:|
| Intact | 12000 | .952578 | .319852 | .468352 | .284828 |
| Intact | 24000 | .944830 | .327596 | .479492 | .280876 |
| Intact | 48000 | .783228 | .457144 | .516601 | .237886 |
| Damaged | 12000 | .958093 | .289688 | .497397 | .283638 |
| Damaged | 24000 | .943997 | .303042 | .509509 | .277967 |
| Damaged | 48000 | .783604 | .423435 | .553549 | .238061 |

The long run reduces gap relative error by about18% relative to12000 steps for both specimens. Correlation and RMS recovery improve as well. Improvements are not uniform in iteration count: damaged c shifts sharply around35000–36000 steps, and intact c around44000–45000 steps. Gap error at36000 steps was .931308 intact and .786175 damaged; at42000 steps .917747 intact and .784457 damaged. The timing is consistent with a change in the joint optimization trajectory, but does not prove a particular local-minimum mechanism or convergence to the true material coefficient. The final fields still have substantial missing-region error.

The12000-step reconstructed arrays were verified bit-for-bit identical to the prior saved experiment. A small-grid split-run test verified exact resume equivalence. Four SciPy FFT workers were used after the6000-step restart; the transform benchmark and recovered12000-step arrays were bitwise identical. No optimizer moments were reset.
