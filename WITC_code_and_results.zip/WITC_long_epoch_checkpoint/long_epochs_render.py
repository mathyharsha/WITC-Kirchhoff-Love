from pathlib import Path
import time,numpy as np
from PIL import Image,ImageDraw
from gap44_fit import masks
from gap44_show import palette,stack
from windows_fit import read
from render_long import image,font
out=Path('long_epochs')
def render(r):
 case="exterior"
 panels=[('High-SNR reference',stack(*(read(s,'high_snr_gt',200,400) for s in ['intact','damaged'])))]
 for step in [12000,24000,48000]:panels.append((f'{step:,} Adam steps',stack(*(np.load(out/f'{s}_r{r}_e{step}.npy') for s in ['intact','damaged']))))
 frames=[];pal=palette()
 for i in range(200):
  im=Image.new('RGB',(1070,465),'white');d=ImageDraw.Draw(im)
  d.text((12,8),f'44 × 88 missing block · {masks("intact")[case].sum():,} measured exterior traces',font=font(20,True),fill='#162830')
  d.text((1058,37),f'{20+i/10:.1f} µs',anchor='ra',font=font(16),fill='#162830')
  d.text((12,37),f'{"Constant λ" if r==0 else "Positive exponential λ, decay length "+str(r)+" pixels"} · 20.0–39.9 µs fit',font=font(14),fill='#2d3f48')
  for col,(title,fields) in enumerate(panels):
   x=130+col*234;d.text((x+110,66),title,anchor='ma',font=font(16,True),fill='#162830')
   for row,a in enumerate(fields):
    y=95+row*116
    if col==0:d.text((10,y+43),['Intact','Damaged','Damaged −\nintact'][row],font=font(15,True),fill='#162830')
    im.paste(Image.fromarray(image(a[:,:,i])).resize((220,110),Image.Resampling.NEAREST),(x,y))
    d.rectangle((x+13,y+7,x+206,y+102),outline=(245,165,42),width=1)
  d.text((12,445),'Same color range [−1,1] · Orange rectangle: unobserved region · One atom · Uniform physics penalty',font=font(12),fill='#2d3f48')
  frames.append(im.quantize(palette=pal,dither=Image.Dither.NONE))
 p=out/f'WITC_long_r{r}_epochs.gif'
 frames[0].save(p,save_all=True,append_images=frames[1:],duration=90,loop=0,optimize=False)
 frames[100].convert('RGB').save(out/f'WITC_long_r{r}_epochs_30us.png')
 with Image.open(p) as check:assert check.n_frames==200;check.seek(199);check.load()
 print('GIF READY',p,flush=True)
if __name__=='__main__':
 for r in [16]:render(r)
