import sys,numpy as np,pandas as pd
import WITC_KL_long_epochs as k
from windows_fit import read,metrics
from gap44_fit import masks,hole
step=int(sys.argv[1]);rows=[]
for s in ['intact','damaged']:
 state=np.load(f'long_epochs/{s}_r16_optimizer_e{step}.npz');a=read(s,'low_snr',200,400);m=masks(s)['exterior'];g=read(s,'high_snr_gt',200,400)
 b=k.reconstruct(state['atom'][:,None],np.array([state['weight']]),a.shape)*abs(a[m]).max()
 err,pcc=metrics(b,g,~hole);rows.append(dict(specimen=s,steps=step,c_m2_s=float(state['c']),relative_L2=err,mean_spatial_PCC=pcc,rms_ratio=np.linalg.norm(b[hole])/np.linalg.norm(g[hole])))
pd.DataFrame(rows).to_csv(f'long_epochs/interim_{step}.csv',index=False)
print(pd.DataFrame(rows).to_string(index=False))
