import numpy as np,pandas as pd
from PIL import Image,ImageDraw
from joint40_run import OUT
from gap44_show import palette,stack
from render_long import image,font
data={s:np.load(OUT/f'{s}_input.npz') for s in ['intact','damaged']}
cs=pd.read_csv(OUT/'comparison_metrics.csv');cs=cs[cs.method=='40 µs joint'].drop_duplicates('specimen').set_index('specimen').c_m2_s
refs=stack(*(data[s]['reference'] for s in data));obs=stack(*(np.where(data[s]['mask'][...,None],data[s]['low'],0) for s in data))
new=stack(*(np.load(OUT/f'{s}_joint40.npy') for s in data));old=stack(*(np.load(OUT/f'{s}_joint20.npy') for s in data))
for overlap in [False,True]:
 panels=[('High-SNR reference',refs),('Observed low-SNR',obs)]
 if overlap:panels.append(('20 µs joint fit',old))
 panels.append(('40 µs joint fit',new));length=200 if overlap else 400;width=1070 if overlap else 836
 frames=[];pal=palette()
 for t in range(length):
  im=Image.new('RGB',(width,490),'white');d=ImageDraw.Draw(im)
  d.text((12,8),'40 µs joint reconstruction · 48,000 Adam steps',font=font(20,True),fill='#162830')
  d.text((12,37),'Fit interval 20–59.9 µs · One atom · Fixed 44 × 88 missing rectangle',font=font(14),fill='#2d3f48')
  d.text((width-12,37),f'{20+t/10:.1f} µs',anchor='ra',font=font(16),fill='#162830')
  for col,(title,fields) in enumerate(panels):
   x=130+col*234;d.text((x+110,66),title,anchor='ma',font=font(15,True),fill='#162830')
   for row,a in enumerate(fields):
    y=95+row*116
    if col==0:d.text((10,y+43),['Intact','Damaged','Damaged −\nintact'][row],font=font(15,True),fill='#162830')
    im.paste(Image.fromarray(image(a[:,:,t])).resize((220,110),Image.Resampling.NEAREST),(x,y));d.rectangle((x+13,y+7,x+206,y+102),outline=(245,165,42),width=1)
  d.text((12,445),f'40 µs fit c: intact {cs["intact"]:.4f}, damaged {cs["damaged"]:.4f} m²/s · Color range [−1,1]',font=font(12),fill='#2d3f48')
  d.text((12,466),'Positive exponential λ · Decay length 16 pixels · Orange: unobserved block',font=font(12),fill='#2d3f48')
  frames.append(im.quantize(palette=pal,dither=Image.Dither.NONE))
 tag='joint40_vs_joint20' if overlap else 'joint40_full'
 p=OUT/f'WITC_{tag}_48000.gif';frames[0].save(p,save_all=True,append_images=frames[1:],duration=90,loop=0,optimize=False)
 frames[80 if overlap else 280].convert('RGB').save(OUT/f'{tag}_preview.png')
 with Image.open(p) as f:assert f.n_frames==length;f.seek(length-1);f.load()
 print('GIF READY',p)
