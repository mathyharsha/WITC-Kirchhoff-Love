"""Compare 20 updates from an actual saved state before switching backends."""
import json,time
from pathlib import Path
import numpy as np
from scipy.fft import set_workers
import WITC_KL_long_epochs as original
import WITC_KL_long_epochs_fused as fused
out=Path('joint40');report=[]
for s in ['intact','damaged']:
 f=np.load(out/f'{s}_input.npz');m=f['mask'];a=np.where(m[...,None],f['low']/float(f['scale']),0)
 with np.load(out/f'{s}_optimizer_latest.npz') as f:state=dict(f)
 lm=original.distance_lambda(m,.01,16)[0];end=int(state['step'])+20;results=[]
 for lib in [original,fused]:
  states=[];start=time.perf_counter()
  with set_workers(4):
   D,w,c=lib.wave_informed_mat_fac(a,m,lambda_map=lm,adam_max_steps=end,resume_state=state,state_callback=states.append,checkpoint_every=end)
  results.append((D,w,c,states[-1],time.perf_counter()-start))
 row=dict(specimen=s,start_step=int(state['step']),tested_steps=20,original_seconds=results[0][4],fused_seconds=results[1][4])
 for idx,name in [(0,'atom'),(1,'weight'),(2,'c')]:
  x,y=results[0][idx],results[1][idx]
  row[name+'_relative_difference']=float(np.linalg.norm(x-y)/(np.linalg.norm(x)+1e-30))
  np.testing.assert_allclose(x,y,rtol=1e-8,atol=1e-10)
 for name in ['md','vd','mw','vw']:
  x,y=np.asarray(results[0][3][name]),np.asarray(results[1][3][name])
  delta=float(np.linalg.norm(x-y)/(np.linalg.norm(x)+1e-30));row[name+'_relative_difference']=delta
  assert delta<1e-8,(name,delta)
 row['passed']=True;report.append(row);print(row,flush=True)
(out/'backend_verification.json').write_text(json.dumps(report,indent=2))
