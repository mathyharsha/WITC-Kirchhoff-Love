# Joint 40 µs reconstruction beginning at 20 µs

Intact and damaged data, indices 200:600, sample times 20.0–59.9 µs (400 samples at dt=0.1 µs). Each specimen is fitted jointly with one full space-time atom, one learned c, and 48,000 Adam epochs. No internal window boundaries. Same KL-WITC implementation as the previous 20 µs fit: lambda0=.01, positive exponential amplitude penalty lambda(x,y)=.01 exp(-distance/16 pixels), gamma=1e-4, lr=1e-4, composed second-order Laplacians, conditional c updates, and c bounds [0.5 PAPER_C,2 PAPER_C]. c has units m²/s, not m/s.

Fixed 50×100 grid, dx=dy=0.2 mm. The central 44×88 rectangle [3:47,6:94] is missing at all times; all 1128 exterior traces are observed. Inputs are normalized by maximum absolute observed low-SNR value over the full fit interval. Reference high-SNR data are used only for evaluation. No new registration or calibration is applied to damaged-minus-intact fields.

Saved 20 µs baseline covers 20–39.9 µs. Input/reference frames on that overlap are checked to match exactly. Compare the two fits on that common interval; additionally report 40 µs full-interval and 40–59.9 µs late-interval errors separately. Numeric regularization settings are held fixed, but the objective's observed-data norm and temporal operator depend on interval length. The full-duration GIF never extrapolates the old 20 µs prediction. GIFs share the fixed [-1,1] color scale, while metrics use unclipped arrays.

Prior independent 3.4, 5, and 10 µs chunking trials are retained as negative results for those tested configurations, not evidence that all possible chunking schemes fail.

Run OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 joint40_run.py, then joint40_report.py and joint40_render.py. NumPy, SciPy, Pandas, Matplotlib and Pillow are required. Inputs and baseline arrays are included, so raw scan files are unnecessary for reproduction. Optimizer states resume automatically and preserve Adam moments. Four FFT workers per specimen are used.

## Numerical acceleration

The first 6000 epochs used the original NumPy implementation. Subsequent epochs resume the same Adam state using an equivalent fused implementation: Parseval identity computes the scalar coefficient gradient in physical coordinates; transform linearity combines two forward transforms; a compiled C loop combines pointwise Adam and conditional c calculations. No objective, learning rate, initialization, epoch budget, or c bounds were changed. Original and accelerated implementations were compared for 20 updates from each actual 6000-step state. Relative differences were below 2.2e-13 for atoms, 1.9e-13 for c, and 1.4e-11 for Adam moments. Floating-point trajectories need not remain bit-identical. Verification results and source are included. The accelerated path compiles witc_pointwise.c using cc without fast-math; if cc is unavailable, or WITC_BACKEND=original is set, the runner uses the original NumPy implementation.

## Completed 48000-epoch results

The 40 µs fit slightly increases missing-block relative error over the shared first 20 µs (intact 0.78323 to 0.79102; damaged 0.78360 to 0.78840), while providing one continuous reconstruction for 400 frames. The added 40–59.9 µs interval remains less accurate. Estimated c is 0.2414718953 m²/s for intact and 0.2413817782 m²/s for damaged. Agreement between specimens does not establish agreement with the physical parameter. Reconstructed amplitudes remain attenuated.

```
specimen      method   interval  steps   c_m2_s  relative_L2  mean_spatial_PCC  rms_ratio
  intact 40 µs joint 20–59.9 µs  48000 0.241472     0.803075          0.507841   0.503612
  intact 40 µs joint 20–39.9 µs  48000 0.241472     0.791021          0.453973   0.502903
  intact 40 µs joint 40–59.9 µs  48000 0.241472     0.823207          0.561708   0.504817
  intact 20 µs joint 20–39.9 µs  48000      NaN     0.783228          0.457144   0.516601
 damaged 40 µs joint 20–59.9 µs  48000 0.241382     0.813762          0.464700   0.549276
 damaged 40 µs joint 20–39.9 µs  48000 0.241382     0.788401          0.423811   0.538798
 damaged 40 µs joint 40–59.9 µs  48000 0.241382     0.865827          0.505589   0.571176
 damaged 20 µs joint 20–39.9 µs  48000      NaN     0.783604          0.423435   0.553549
```
