import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from joint40_run import OUT
rows=[]
fig,axs=plt.subplots(2,1,figsize=(11,6),sharex=True,layout='constrained')
for ax,s in zip(axs,['intact','damaged']):
 with np.load(OUT/f'{s}_input.npz') as f:g=f['reference'];m=f['mask']
 for method,name,n in [('40 µs joint','joint40',400),('20 µs joint','joint20',200)]:
  b=np.load(OUT/f'{s}_{name}.npy');assert b.shape==(50,100,n) and np.isfinite(b).all()
  errors=np.linalg.norm((b-g[:,:,:n])[~m],axis=0)/np.linalg.norm(g[~m,:n],axis=0)
  ax.plot(20+np.arange(n)/10,errors,label=method)
  rows.extend(dict(specimen=s,method=method,time_us=20+i/10,relative_L2=v) for i,v in enumerate(errors))
 ax.axvline(40,color='gray',ls=':',lw=.8);ax.set(title=s.capitalize(),ylabel='Missing-block relative L2 error');ax.grid(alpha=.2);ax.legend()
axs[-1].set_xlabel('Time (µs)');fig.savefig(OUT/'joint40_frame_errors.png',dpi=150)
pd.DataFrame(rows).to_csv(OUT/'frame_metrics.csv',index=False)
print(pd.read_csv(OUT/'comparison_metrics.csv').to_string(index=False))
