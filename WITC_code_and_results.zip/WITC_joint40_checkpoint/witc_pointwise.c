#include <math.h>
#include <stddef.h>
double prepare(size_t n, const double *d, const double *obs, const unsigned char *mask,
 const double *lm, double w, double scale, double *rhs) {
 double gw=0.;
 for(size_t i=0;i<n;i++) {
  double res=mask[i] ? w*d[i]-obs[i] : 0.;
  rhs[i]=w*res+scale*lm[i]*d[i];gw+=d[i]*res;
 }
 return gw;
}
void update(size_t n,size_t nt,double *atom,double *md,double *vd,const double *z,
 const double *space,const double *time,double c,double reg,double lr,double b1,double b2,
 int measure,double *out) {
 double numerator=0.,denominator=0.,dn=0.,an=0.;
 for(size_t i=0;i<n;i++) {
  double sp=space[i/nt],tm=time[i%nt],r=sp+tm/(c*c),old=atom[i];
  double gd=z[i]+reg*r*r*old;
  md[i]=.9*md[i]+.1*gd;vd[i]=.999*vd[i]+.001*gd*gd;
  double delta=lr*(md[i]/b1)/(sqrt(vd[i]/b2)+1e-8);
  atom[i]=old-delta;
  double en=atom[i]*atom[i];numerator+=en*(-sp*tm);denominator+=en*(tm*tm);
  if(measure){dn+=delta*delta;an+=old*old;}
 }
 out[0]=numerator;out[1]=denominator;out[2]=sqrt(dn)/(sqrt(an)+1e-12);
}
