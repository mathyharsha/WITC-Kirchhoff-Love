from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import numpy as np,pandas as pd
from scipy.fft import set_workers
import os,shutil
if os.environ.get("WITC_BACKEND", "fused")=="fused" and shutil.which("cc"):
 import WITC_KL_long_epochs_fused as kl
else:
 import WITC_KL_long_epochs as kl
from chunk34_run import evaluate
OUT=Path('joint40');OUT.mkdir(exist_ok=True)
def prepare():
 from windows_fit import read
 for s in ['intact','damaged']:
  if (OUT/f'{s}_input.npz').exists():continue
  a=read(s,'low_snr',200,600);g=read(s,'high_snr_gt',200,600)
  old=np.load(f'longer_windows/{s}_input.npz');m=old['mask'];scale=float(np.abs(a[m]).max())
  assert np.array_equal(a[:,:,:200],old['low']) and np.array_equal(g[:,:,:200],old['reference'])
  np.savez(OUT/f'{s}_input.npz',low=a,reference=g,mask=m,scale=scale)
  np.save(OUT/f'{s}_joint20.npy',np.load(f'longer_windows/{s}_joint20.npy'))
  print('INPUT',s,a.shape,'scale',scale,'previous scale',float(old['scale']),flush=True)
def fit(s):
 with np.load(OUT/f'{s}_input.npz') as f:a=f['low'];g=f['reference'];m=f['mask'];scale=float(f['scale'])
 lm,_=kl.distance_lambda(m,.01,16);state_path=OUT/f'{s}_optimizer_latest.npz';resume=None;history=[]
 if state_path.exists():
  with np.load(state_path) as f:resume={key:f[key] for key in f.files}
  if (OUT/f'{s}_history.csv').exists():history=pd.read_csv(OUT/f'{s}_history.csv').to_dict('records')
 def save(state):
  tmp=OUT/f'{s}_tmp.npz';np.savez(tmp,**state);tmp.replace(state_path)
 def progress(row):
  history.append(row);pd.DataFrame(history).to_csv(OUT/f'{s}_history.csv',index=False);print(s,row,flush=True)
 with set_workers(4):D,w,c=kl.wave_informed_mat_fac(np.where(m[...,None],a/scale,0),m,lambda_map=lm,adam_max_steps=48000,checkpoint_every=6000,state_callback=save,resume_state=resume,callback=progress,log_every=3000)
 b=kl.reconstruct(D,w,a.shape)*scale;np.save(OUT/f'{s}_joint40.npy',b)
 rows=[]
 for label,i,j in [('20–59.9 µs',0,400),('20–39.9 µs',0,200),('40–59.9 µs',200,400)]:
  rows.append(dict(specimen=s,method='40 µs joint',interval=label,steps=48000,c_m2_s=float(c[0]),**evaluate(b[:,:,i:j],g[:,:,i:j],~m)))
 rows.append(dict(specimen=s,method='20 µs joint',interval='20–39.9 µs',steps=48000,c_m2_s=np.nan,**evaluate(np.load(OUT/f'{s}_joint20.npy'),g[:,:,:200],~m)))
 pd.DataFrame(rows).to_csv(OUT/f'{s}_metrics.csv',index=False);print('DONE',rows,flush=True);return rows
if __name__=='__main__':
 prepare()
 with ProcessPoolExecutor(2) as pool:rows=sum(pool.map(fit,['intact','damaged']),[])
 pd.DataFrame(rows).to_csv(OUT/'comparison_metrics.csv',index=False)
