# Independent 3.4 µs chunks, 48,000 Adam steps each

Fixed spatial setup:50x100 grid, central44x88 unobserved rectangle [3:47,6:94], all1128 exterior traces observed. Five independent contiguous chunks of34 samples each:indices230:264,264:298,298:332,332:366,366:400 atdt=.1µs. Sample times23.0–26.3,26.4–29.7,29.8–33.1,33.2–36.5,36.6–39.9µs. Each half-open interval has duration3.4µs. No gap, overlap, blending or shared optimization state between chunks.

One full space-time atom and one learned c per chunk; each fit uses48000 Adam steps, lr1e-4, gamma1e-4, lambda0=.01, spatial lambda=.01exp(-distance/16pixels). Physics and coefficient penalties stay uniform. Laplacians are composed to construct the biharmonic operator. Same c bounds and initializer as the previous experiments. c is updated conditionally at each step. The finite temporal operator now has an independent boundary closure in each short chunk.

Each specimen uses one common normalization:maximum absolute observed low-SNR value across23–39.9µs, so independently fitted chunks share amplitude units. Outputs are returned to original units before concatenation/evaluation. High-SNR references are evaluation-only. Mask and regularization map are constant over time. Full original chunk inputs and masks are included in *_input.npz; no external dataset is needed to repeat these fits.

The previous48000-step joint prediction was trained on20–39.9µs and is shown/evaluated only on23–39.9µs for historical context. It also had its original full-window normalization. This is not a matched-start ablation. The new chunked fit has no observations before23µs in its input or normalization.

Metrics evaluate the full unobserved block with unclipped arrays. Boundary metrics compare predicted and reference frame-to-frame changes at each chunk join. jump_ratio=||pred(t+)-pred(t-)||/||ref(t+)-ref(t-)||; jump_relative_error=||pred jump-ref jump||/||ref jump||. A nonzero frame change is physically expected; these are reference-relative diagnostics, not a continuity theorem.

GIF rows:intact,damaged,raw damaged-minus-intact. Columns:reference,observed low-SNR,previous joint fit,new chunks. Color scale[-1,1] is identical, with display-only clipping. No extra registration/calibration of difference fields. Run chunk34_run.py (NumPy/SciPy/Pandas), then chunk34_report.py and chunk34_render.py (Matplotlib/Pillow). OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 is recommended. The runner resumes each saved optimizer state automatically. Five independent initializations per specimen are used, rather than warm-starting later chunks.

## Completed results


stitched_metrics.csv

```
specimen                         method  relative_L2  mean_spatial_PCC  rms_ratio
  intact Previous joint fit (20–39.9us)     0.776441          0.501129   0.511979
  intact       Independent 3.4us chunks     0.935223          0.352252   0.520893
 damaged Previous joint fit (20–39.9us)     0.775102          0.486527   0.545029
 damaged       Independent 3.4us chunks     0.943328          0.330768   0.553735
```

chunk_metrics.csv

```
specimen  chunk  start_us  last_sample_us  stop_exclusive_us  frames  steps   c_m2_s  relative_L2  mean_spatial_PCC  rms_ratio
  intact      1      23.0            26.3               26.4      34  48000 0.320828     1.274345          0.186663   1.004544
  intact      2      26.4            29.7               29.8      34  48000 0.245579     0.876735          0.481595   0.440349
  intact      3      29.8            33.1               33.2      34  48000 0.269186     0.905232          0.430476   0.513663
  intact      4      33.2            36.5               36.6      34  48000 0.202398     0.920180          0.392986   0.444026
  intact      5      36.6            39.9               40.0      34  48000 0.177275     0.976335          0.269538   0.428647
 damaged      1      23.0            26.3               26.4      34  48000 0.294500     1.188295          0.215000   1.024492
 damaged      2      26.4            29.7               29.8      34  48000 0.245789     0.888231          0.448733   0.446007
 damaged      3      29.8            33.1               33.2      34  48000 0.260305     0.915379          0.415826   0.546196
 damaged      4      33.2            36.5               36.6      34  48000 0.196622     0.956960          0.317757   0.488350
 damaged      5      36.6            39.9               40.0      34  48000 0.211754     1.003496          0.256523   0.527929
```

boundary_metrics.csv

```
specimen                         method  boundary_us  jump_ratio  jump_relative_error
  intact Previous joint fit (20–39.9us)         26.4    0.633641             0.513013
  intact Previous joint fit (20–39.9us)         29.8    0.604454             0.612054
  intact Previous joint fit (20–39.9us)         33.2    0.969740             1.176725
  intact Previous joint fit (20–39.9us)         36.6    1.626914             1.750774
  intact       Independent 3.4us chunks         26.4    2.814317             3.360384
  intact       Independent 3.4us chunks         29.8    2.603314             3.062216
  intact       Independent 3.4us chunks         33.2    4.733125             4.465783
  intact       Independent 3.4us chunks         36.6    7.042213             6.837618
 damaged Previous joint fit (20–39.9us)         26.4    0.623767             0.548480
 damaged Previous joint fit (20–39.9us)         29.8    0.618661             0.666707
 damaged Previous joint fit (20–39.9us)         33.2    0.816454             1.068512
 damaged Previous joint fit (20–39.9us)         36.6    1.150269             1.455273
 damaged       Independent 3.4us chunks         26.4    2.656488             3.243035
 damaged       Independent 3.4us chunks         29.8    2.718250             3.097684
 damaged       Independent 3.4us chunks         33.2    4.166287             3.967362
 damaged       Independent 3.4us chunks         36.6    5.046991             5.048810
```
