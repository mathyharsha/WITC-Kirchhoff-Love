from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np,pandas as pd
from scipy.fft import set_workers
import WITC_KL_long_epochs as kl
OUT=Path('chunk34');BOUNDS=list(range(230,401,34))
def evaluate(b,g,region):
 x=b[region];y=g[region];err=np.linalg.norm(x-y)/np.linalg.norm(y)
 xc=x-x.mean(0);yc=y-y.mean(0);den=np.sqrt(np.sum(xc*xc,0)*np.sum(yc*yc,0))
 pcc=np.mean(np.divide(np.sum(xc*yc,0),den,out=np.full_like(den,np.nan),where=den>0))
 return dict(relative_L2=float(err),mean_spatial_PCC=float(pcc),rms_ratio=float(np.linalg.norm(x)/np.linalg.norm(y)))
def fit(job):
 specimen,j=job;tag=f'{specimen}_chunk{j+1}';i,k=BOUNDS[j:j+2]
 with np.load(OUT/f'{specimen}_input.npz') as f:a=f['low'][:,:,i-230:k-230];g=f['reference'][:,:,i-230:k-230];mask=f['mask'];scale=float(f['scale'])
 lm,_=kl.distance_lambda(mask,lambda0=.01,radius=16)
 state_path=OUT/f'{tag}_optimizer_latest.npz';resume=None;history=[]
 if state_path.exists():
  with np.load(state_path,allow_pickle=False) as f:resume={key:f[key] for key in f.files}
  if (OUT/f'{tag}_history.csv').exists():history=pd.read_csv(OUT/f'{tag}_history.csv').to_dict('records')
 def state_callback(state):
  tmp=OUT/f'{tag}_tmp.npz';np.savez(tmp,**state);tmp.replace(state_path)
 def progress(row):
  history.append(row);pd.DataFrame(history).to_csv(OUT/f'{tag}_history.csv',index=False);print(tag,row,flush=True)
 with set_workers(1):D,w,c=kl.wave_informed_mat_fac(np.where(mask[...,None],a/scale,0),mask,lambda_map=lm,adam_max_steps=48000,checkpoint_every=12000,state_callback=state_callback,resume_state=resume,callback=progress,log_every=12000)
 b=kl.reconstruct(D,w,a.shape)*scale;np.save(OUT/f'{tag}.npy',b)
 row=dict(specimen=specimen,chunk=j+1,start_us=i/10,last_sample_us=(k-1)/10,stop_exclusive_us=k/10,frames=k-i,steps=48000,c_m2_s=float(c[0]),**evaluate(b,g,~mask))
 pd.DataFrame([row]).to_csv(OUT/f'{tag}_metrics.csv',index=False);print('DONE',row,flush=True);return row
if __name__=='__main__':
 assert BOUNDS==[230,264,298,332,366,400]
 with ProcessPoolExecutor(10) as pool:rows=list(pool.map(fit,[(s,j) for s in ['intact','damaged'] for j in range(5)]))
 pd.DataFrame(rows).to_csv(OUT/'chunk_metrics.csv',index=False)
