from pathlib import Path
import json,numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from chunk34_run import OUT,BOUNDS,evaluate
rows=[];seams=[];frame_rows=[]
for s in ['intact','damaged']:
 with np.load(OUT/f'{s}_input.npz') as f:g=f['reference'];mask=f['mask']
 b=np.concatenate([np.load(OUT/f'{s}_chunk{j}.npy') for j in range(1,6)],axis=2)
 assert b.shape==g.shape==(50,100,170);assert np.isfinite(b).all()
 np.save(OUT/f'{s}_stitched.npy',b)
 old=np.load(OUT/f'{s}_previous_joint.npy')
 for method,pred in [('Previous joint fit (20–39.9us)',old),('Independent 3.4us chunks',b)]:
  rows.append(dict(specimen=s,method=method,**evaluate(pred,g,~mask)))
  for n in range(170):frame_rows.append(dict(specimen=s,method=method,time_us=23+n/10,relative_L2=np.linalg.norm((pred-g)[~mask,n])/np.linalg.norm(g[~mask,n])))
  for idx in [34,68,102,136]:
   dp=pred[~mask,idx]-pred[~mask,idx-1];dg=g[~mask,idx]-g[~mask,idx-1]
   seams.append(dict(specimen=s,method=method,boundary_us=23+idx/10,jump_ratio=np.linalg.norm(dp)/np.linalg.norm(dg),jump_relative_error=np.linalg.norm(dp-dg)/np.linalg.norm(dg)))
df=pd.DataFrame(rows);df.to_csv(OUT/'stitched_metrics.csv',index=False);pd.DataFrame(seams).to_csv(OUT/'boundary_metrics.csv',index=False)
fr=pd.DataFrame(frame_rows);fr.to_csv(OUT/'frame_metrics.csv',index=False)
fig,axes=plt.subplots(2,1,figsize=(11,6),sharex=True,layout='constrained')
for ax,s in zip(axes,['intact','damaged']):
 for method,group in fr[fr.specimen==s].groupby('method',sort=False):ax.plot(group.time_us,group.relative_L2,label=method,lw=1.5)
 for t in [26.4,29.8,33.2,36.6]:ax.axvline(t,color='grey',ls=':',lw=.8)
 ax.set(title=s.capitalize(),ylabel='Gap relative L2 error');ax.grid(alpha=.2);ax.legend()
axes[-1].set_xlabel('Time (µs)');fig.savefig(OUT/'chunk34_frame_errors.png',dpi=160)
c=pd.read_csv(OUT/'chunk_metrics.csv');fig,ax=plt.subplots(figsize=(10,4),layout='constrained')
for s in ['intact','damaged']:
 d=c[c.specimen==s].sort_values('chunk');ax.plot(d.chunk,d.c_m2_s,'o-',label=s.capitalize())
ax.set(xticks=range(1,6),xlabel='Independent chunk',ylabel='Estimated c (m²/s)',title='One c estimate per 3.4 µs chunk');ax.grid(alpha=.2);ax.legend();fig.savefig(OUT/'chunk34_c_estimates.png',dpi=160)
print(df.to_string(index=False));print(c.to_string(index=False));print(pd.DataFrame(seams).to_string(index=False))
