from pathlib import Path
import numpy as np,pandas as pd
from PIL import Image,ImageDraw
from gap44_show import palette,stack
from render_long import image,font
out=Path('chunk34');specimens=['intact','damaged'];inputs={s:np.load(out/f'{s}_input.npz') for s in specimens}
refs=[inputs[s]['reference'] for s in specimens];masked=[np.where(inputs[s]['mask'][...,None],inputs[s]['low'],0) for s in specimens]
panels=[('High-SNR reference',stack(*refs)),('Observed low-SNR',stack(*masked)),('Previous joint fit*',stack(*(np.load(out/f'{s}_previous_joint.npy') for s in specimens))),('Five 3.4 µs chunks',stack(*(np.load(out/f'{s}_stitched.npy') for s in specimens)))]
cs=pd.read_csv(out/'chunk_metrics.csv');frames=[];pal=palette()
for i in range(170):
 j=i//34+1;im=Image.new('RGB',(1070,490),'white');d=ImageDraw.Draw(im)
 d.text((12,8),'44 × 88 missing block · 48,000 Adam steps per chunk · Start 23 µs',font=font(20,True),fill='#162830')
 d.text((12,37),f'Independent chunk {j}/5 · 34 samples per chunk · Positive exponential λ, decay length 16 pixels',font=font(14),fill='#2d3f48')
 d.text((1058,37),f'{23+i/10:.1f} µs',anchor='ra',font=font(16),fill='#162830')
 for col,(title,fields) in enumerate(panels):
  x=130+col*234;d.text((x+110,66),title,anchor='ma',font=font(15,True),fill='#162830')
  for row,a in enumerate(fields):
   y=95+row*116
   if col==0:d.text((10,y+43),['Intact','Damaged','Damaged −\nintact'][row],font=font(15,True),fill='#162830')
   im.paste(Image.fromarray(image(a[:,:,i])).resize((220,110),Image.Resampling.NEAREST),(x,y));d.rectangle((x+13,y+7,x+206,y+102),outline=(245,165,42),width=1)
 ci=cs[(cs.specimen=='intact')&(cs.chunk==j)].c_m2_s.iloc[0];cd=cs[(cs.specimen=='damaged')&(cs.chunk==j)].c_m2_s.iloc[0]
 d.text((12,445),f'Chunk c: intact {ci:.4f}, damaged {cd:.4f} m²/s · Same color range [−1,1] · Orange: unobserved block',font=font(12),fill='#2d3f48')
 d.text((12,466),'*Previous joint fit used 20–39.9 µs; shown cropped to 23–39.9 µs for context.',font=font(12),fill='#2d3f48')
 frames.append(im.quantize(palette=pal,dither=Image.Dither.NONE))
p=out/'WITC_3p4us_chunks_48000.gif';frames[0].save(p,save_all=True,append_images=frames[1:],duration=90,loop=0,optimize=False)
frames[70].convert('RGB').save(out/'WITC_3p4us_chunks_30us.png')
with Image.open(p) as f:assert f.n_frames==170;f.seek(169);f.load()
print('GIF READY',p)
