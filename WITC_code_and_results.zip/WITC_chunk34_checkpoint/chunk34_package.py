from pathlib import Path
import zipfile
out=Path('chunk34')
with zipfile.ZipFile(out/'WITC_chunk34_checkpoint.zip','w',zipfile.ZIP_DEFLATED,compresslevel=1) as z:
 for p in out.iterdir():
  if p.suffix in ['.csv','.md','.npy','.gif','.png'] or p.name.endswith(('_optimizer_latest.npz','_input.npz')):z.write(p,str(p))
 for f in ['chunk34_run.py','chunk34_render.py','chunk34_report.py','chunk34_package.py','WITC_KL_long_epochs.py','WITC_KL_reciprocal.py','WITC_KL_lib.py','gap44_fit.py','gap44_show.py','largest_fit.py','enlarged_fit.py','block_experiment.py','windows_fit.py','run.py','render_long.py']:z.write(f,f)
print(out/'WITC_chunk34_checkpoint.zip')
